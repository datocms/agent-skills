# Web Previews Concepts

DatoCMS Web Previews plugin integration reference.

## Contents

- What the Web Previews Plugin Is
- Plugin Configuration
- Preview-Links Endpoint Contract
- CORS Requirements
- `recordToWebsiteRoute` Pattern
- `reloadPreviewOnRecordUpdate`
- Visual Editing Tab and Content Link
- CSP Requirements
- Plugin Installation
- Dependencies

## What the Web Previews Plugin Is

[Web Previews](https://www.datocms.com/marketplace/plugins/i/datocms-plugin-web-previews) adds three DatoCMS editor features:

1. **Sidebar preview links** — Clickable record sidebar links for draft/published frontend versions
2. **Sidebar iframe preview** — Inline record preview iframe, with optional Content Link click-to-edit
3. **Visual editing tab** — Full-screen tab with frontend iframe for Content Link overlays

All need a **preview-links endpoint** that maps records to URLs.

## Plugin Configuration

Web Previews plugin configures one or more "frontends". Each needs:

- **Preview webhook URL** — Preview-links endpoint URL (e.g., `https://your-site.com/api/preview-links`). Optional: a frontend with only Visual editing needs none
- **Draft mode URL** — The enable endpoint (e.g., `https://your-site.com/api/draft-mode/enable?token=YOUR_SECRET`), configured as `visualEditing.enableDraftModeUrl`. Required for the Visual editing tab and sidebar click-to-edit, together with Content Link query headers and the frontend controller. Ordinary sidebar links/iframes do not require `visualEditing` configuration.
- **Initial path** — Optional default path when Visual editing tab opens (defaults to `/`)
- **Custom headers** — Optional HTTP headers sent to preview-links endpoint. Put the shared secret here as `Authorization: Bearer <SECRET_API_TOKEN>`: starter kits read it from that header and return 401 for a `?token=` query. Only the enable-draft-mode URL keeps `?token=` (editors open it in the browser)
- **Viewport presets** — Optional iframe preview sizes (sidebar and Visual tab)
- **Iframe `allow` attribute** — Optional iframe permissions (microphone, camera). See [MDN iframe allow](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/iframe#allow).

### Sidebar click-to-edit

Sidebar Edit mode is opt-in and off by default. Configure the frontend's `visualEditing.enableDraftModeUrl` and Content Link integration when click-to-edit is requested; opening the sidebar does not enable the user's Edit toggle.

When both Published and Draft previews exist, select Draft to enter Edit mode; keep an explicitly selected Published preview published. When only Published exists, enabling Edit mode loads that page through the configured draft-mode route.

The sidebar integration recognizes the destination in a `redirect` query parameter. Endpoints that read a different parameter (such as `url`) should accept `redirect` when supplied and otherwise retain the old name as a compatibility fallback in both draft-mode endpoints; validate the selected value before redirecting. Emit `redirect` in the preview links used for sidebar click-to-edit so the plugin can identify draft previews and their destinations.

Preserve unrelated frontends, plugin settings, and existing draft/preview endpoints when adding this capability.

## Preview-Links Endpoint Contract

Preview-links endpoint receives POST requests from DatoCMS editor and returns record preview URLs.

### Request Body

```ts
type WebPreviewsRequestBody = {
  item: RawApiTypes.Item;        // The record (raw JSON:API format)
  itemType: RawApiTypes.ItemType; // The model (raw JSON:API: id, attributes.api_key)
  currentUser: object;           // The logged-in DatoCMS user
  siteId: string;                // The DatoCMS project ID
  environmentId: string;         // The environment ID
  locale: string;                // The current locale in the editor
};
```

### Response Format

```ts
type PreviewLink = {
  label: string;
  url: string;
  reloadPreviewOnRecordUpdate?: boolean | { delayInMs: number };
};

type WebPreviewsResponse = {
  previewLinks: PreviewLink[];
};
```

Draft preview URLs contain the shared secret, so the response body is credential-bearing too. During verification, parse and assert the response in memory; print only status, labels and URL pathnames, never the raw body or authenticated URLs.

### Status Branching Logic

Endpoint branches on `item.meta.status`:

- **`status !== 'published'`** — Record has draft version. Generate URL that enables draft mode then redirects to content page.
- **`status !== 'draft'`** — Record has published version. Generate URL that disables draft mode then redirects to content page.
- Both states can exist simultaneously (published with unpublished changes), so both links may be returned.

```ts
const response: WebPreviewsResponse = { previewLinks: [] };

if (url) {
  if (item.meta.status !== 'published') {
    const draftUrl = new URL('/api/draft-mode/enable', requestUrl);
    draftUrl.searchParams.set('redirect', url);
    draftUrl.searchParams.set('token', token);
    response.previewLinks.push({
      label: 'Draft version',
      url: draftUrl.toString(),
    });
  }

  if (item.meta.status !== 'draft') {
    const publishedUrl = new URL('/api/draft-mode/disable', requestUrl);
    publishedUrl.searchParams.set('redirect', url);
    response.previewLinks.push({
      label: 'Published version',
      url: publishedUrl.toString(),
    });
  }
}
```

**Published URL:** the plugin sends only the current version, so when `item.meta.status === 'updated'` the published URL can differ (e.g. an unpublished slug change). Starter kits compute it from `client.items.rawFind(item.id, { version: 'published' })` (environment from `environmentId`) and fall back to the draft URL if that fails.

### Endpoint Error Behavior

- **Non-200 status** — Plugin logs "returned a {status} status" and shows no preview links
- **Invalid JSON or wrong structure** — Plugin logs "returned an invalid payload"
- **Empty `{ previewLinks: [] }`** — Normal for records without frontend URLs (settings singletons, reusable blocks)
- Always return 200 with empty `previewLinks` array for unmatched records, not error status

## CORS Requirements

Preview-links endpoint receives POST requests from DatoCMS editor (different origin). Needs CORS headers:

```ts
function withCORS(responseInit?: ResponseInit): ResponseInit {
  return {
    ...responseInit,
    headers: {
      ...responseInit?.headers,
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'OPTIONS, POST, GET',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  };
}
```

Handle `OPTIONS` preflight:

```ts
export async function OPTIONS() {
  return new Response('OK', withCORS());
}
```

**Nuxt exception:** Handles CORS via `routeRules` in `nuxt.config.ts`:

```ts
routeRules: {
  '/api/**': { cors: true },
}
```

## `recordToWebsiteRoute` Pattern

The incoming JSON:API item has `relationships.item_type.data.id`, not `__itemTypeId`. The latter is a local discriminator added by `deserializeRawItem`; accepting it as an optional request field does not populate it. Deserialize the wire item before routing, or read its raw relationship directly. Test the endpoint with the actual raw payload, without SDK-added properties.

Maps DatoCMS record to frontend URL. Used by preview-links endpoint.

Same pattern across all frameworks: deserialize the raw item with `deserializeRawItem` from `@datocms/rest-client-utils`, then switch on `item.__itemTypeId`. With `cma-types` generated (`npx datocms schema:generate src/lib/datocms/cma-types.ts`; path = where the `cma-types` import resolves), each `case Schema.X.ID` narrows `item.attributes` to that model's fields — no `as` casts needed.

Skeleton:

```ts
import type { RawApiTypes } from '@datocms/cma-client';
import * as Schema from '@/lib/datocms/cma-types';

export async function recordToWebsiteRoute(
  item: RawApiTypes.Item<Schema.AnyModel>,
  _locale: string,
): Promise<string | null> {
  switch (item.__itemTypeId) {
    // case Schema.Page.ID:
    //   return `/${item.attributes.slug}`;
    // case Schema.BlogPost.ID:
    //   return `/blog/${item.attributes.slug}`;
    default:
      return null;
  }
}
```

User must fill in their own models. Provide commented-out examples.

## `reloadPreviewOnRecordUpdate`

Each preview link can specify `reloadPreviewOnRecordUpdate` to control iframe refresh behavior when editor saves record:

- `true` — Reloads after 100ms delay
- `{ delayInMs: N }` — Reloads after custom delay in milliseconds

Triggered when record's version changes (on save). Delay useful for frameworks needing rebuild/revalidate time before preview reflects changes (e.g., Next.js ISR revalidation).

**Note:** Cross-origin iframe restrictions prevent maintaining scroll position between reloads — page reloads from top.

## Visual Editing Tab and Content Link

Visual editing tab loads your frontend in full-screen DatoCMS iframe. With Content Link, enables visual editing where editors click elements to open corresponding fields in side panel.

### How It Works

1. Plugin loads your frontend URL in iframe (uses "Draft mode URL" setting to auto-enable draft mode)
2. `@datocms/content-link` library detects iframe context and establishes Penpal connection with plugin — **automatic, no configuration needed**
3. When editor clicks element with Content Link overlay, click communicated to plugin which opens field in side panel (not new tab)
4. **Bidirectional routing** keeps plugin and website in sync:
   - Plugin → Website: When editor navigates to different record, plugin calls `onNavigateTo` (passed to `createController()`)
   - Website → Plugin: When client-side navigation occurs, call `controller.setCurrentPath(path)` to notify plugin

### Graceful Fallback

If frontend not running inside plugin iframe (e.g., opened directly in browser), Content Link falls back to opening edit URLs in new browser tabs. No code changes needed.

See `content-link-concepts.md` for full Content Link documentation including `createController()` API, data attributes, structured text patterns, troubleshooting.

## CSP Requirements

First inspect the frontend's response headers and CSP configuration.

- If the frontend does not send a `frame-ancestors` directive, no CSP change is required for Web Previews. Do not add the directive solely for this integration.
- If the frontend sends `frame-ancestors`, it must allow every origin in the nested iframe chain: the exact origin from which editors access the DatoCMS project and `https://plugins-cdn.datocms.com`. The project origin is normally `https://<PROJECT-SUBDOMAIN>.admin.datocms.com`; use its custom DatoCMS admin origin instead when applicable.
- If the exact DatoCMS project origin cannot be determined from the repository or current context, ask the user to provide it before changing `frame-ancestors`. Do not guess it or use a wildcard.

Browsers validate every ancestor, so allowing only the plugin CDN is insufficient. Replace `your-project` with the project's actual subdomain:

```
frame-ancestors 'self' https://your-project.admin.datocms.com https://plugins-cdn.datocms.com
```

## Plugin Installation

Baseline: DatoCMS CLI present and repo linked via `npx datocms link` (so `datocms.config.json` exists and `cma:script` auth works out of the box). Default to programmatic install. Fall back to manual UI only when CLI not linked.

### Programmatic install (default)

`plugins.list` first — reuse the installed `datocms-plugin-web-previews` instead of creating a duplicate, else `plugins.create`; then `plugins.update` writes `parameters`. `parameters` is sent whole: merge into the saved object (other frontends, settings); omitting it keeps saved settings ([resource-gotchas.md › Plugins](../../datocms-cma/references/resource-gotchas.md#plugins-plugins)). Execution surface depends on repo:

- **One-off** — `npx datocms cma:script` stdin or file. No tracking; the list check keeps re-runs from duplicating the plugin.
- **Migration script** (preferred when repo has `migrations/`) — `npx datocms migrations:new "install web previews plugin" --ts` scaffolds a file exporting `async function(client: Client)`. CLI tracks runs via `schema_migration` model, so install only happens once per environment. Idempotent + versioned + replays on `migrations:run` against forked envs. Default `migrations:run` installs the plugin in the sandbox it forks ([running-migrations.md › Default Behavior (Fork-and-Run)](../../datocms-cli/references/running-migrations.md#default-behavior-fork-and-run)) — primary gets it only after that env is promoted (or via `--in-place --allow-primary`, additive-only). Name the target environment in the plan and handoff.

```ts
// Read at run time (the CLI loads .env.local/.env); never inline values in a committed migration.
const baseUrl = process.env.SITE_URL; // or the repo's *_SITE_URL (see seo-concepts.md › Canonical URLs and Site URL)
// the framework's secret var: NUXT_SECRET_API_TOKEN (Nuxt), PRIVATE_SECRET_API_TOKEN (SvelteKit)
const SECRET_API_TOKEN = process.env.SECRET_API_TOKEN;
if (!baseUrl || !SECRET_API_TOKEN) throw new Error('Missing site URL or preview secret');

const frontend = {
  name: 'Production',
  previewWebhook: `${baseUrl}/api/preview-links`,
  visualEditing: {
    enableDraftModeUrl: `${baseUrl}/api/draft-mode/enable?token=${SECRET_API_TOKEN}`,
    initialPath: '/',
  },
};

const plugin =
  (await client.plugins.list()).find((p) => p.package_name === 'datocms-plugin-web-previews') ??
  (await client.plugins.create({ package_name: 'datocms-plugin-web-previews' }));

// Keep other frontends and settings; update this frontend by name, keeping its other keys (customHeaders).
const { frontends, ...settings } = plugin.parameters;
const saved = Array.isArray(frontends) ? frontends.find((f) => f?.name === frontend.name) : undefined;
const otherFrontends = Array.isArray(frontends)
  ? frontends.filter((f) => f?.name !== frontend.name)
  : [];

// The secret travels as a header, replacing any saved Authorization header and keeping the others.
const customHeaders = [
  ...(saved?.customHeaders ?? []).filter((h) => h.name.toLowerCase() !== 'authorization'),
  { name: 'Authorization', value: `Bearer ${SECRET_API_TOKEN}` },
];

await client.plugins.update(plugin.id, {
  parameters: { startOpen: true, ...settings, frontends: [...otherFrontends, { ...saved, ...frontend, customHeaders }] },
});
```

### `parameters.frontends[]` shape

Plugin-specific, not in `cma:docs plugins create`. One entry per frontend:

| Key | Type | Required | Notes |
| - | - | - | - |
| `name` | string | yes | Frontend label (`Production`, `Staging`, etc.) |
| `previewWebhook` | string | no | Absolute URL of preview-links endpoint, without the secret. Omit for Visual-only frontends |
| `customHeaders` | `{ name, value }[]` | no | Headers sent to the preview-links endpoint; carries `Authorization: Bearer <secret>` |
| `visualEditing.enableDraftModeUrl` | string | for Visual editing tab or sidebar click-to-edit | Absolute URL of draft-mode enable endpoint with secret token. Omit `visualEditing` for ordinary sidebar links/iframes when neither editing feature is requested |
| `visualEditing.initialPath` | string | no | Default path when Visual editing tab opens (defaults to `/`) |

Top-level `parameters.startOpen: true` opens the sidebar panel by default (it only applies to the sidebar panel).

### Confirm before executing

Plugin install writes to live DatoCMS project. Echo resolved `frontends[]` config back to user and confirm before calling `plugins.create` / `plugins.update`. Saved same-name frontend has `customHeaders` or `disabled: true` → say so in the echo (both carry over; `disabled` keeps its preview links and Visual editing off).

### Manual UI fallback

If CLI not linked, instruct user:

1. DatoCMS → Configuration → Plugins → Add new
2. Search "Web Previews" in marketplace, install
3. Open plugin settings, paste the same `frontends[]` values into the form (preview webhook URL, draft mode URL, initial path, viewport presets, custom headers including the `Authorization` header)

## Dependencies

Preview-links endpoint requires, in all four frameworks:

- `@datocms/cma-client` — `RawApiTypes` types for the endpoint body and `recordToWebsiteRoute`
- `@datocms/rest-client-utils` — `deserializeRawItem` to convert raw JSON:API item before passing to `recordToWebsiteRoute`
