# Vue Real-Time Updates — `useQuerySubscription`

Vue 3 composable for live content updates via DatoCMS's [Real-time Updates API](https://www.datocms.com/docs/real-time-updates-api/api-reference). Receives updated query results in real-time over Server-Sent Events (SSE) and reconnects automatically on network failures.

See `realtime-concepts.md` for shared initialization options, connection status values, error object shape, and the `fetcher` gotcha.

`token` reaches the browser: pass the draft CDA token (e.g. `DATOCMS_DRAFT_CONTENT_CDA_TOKEN`) in from the server only while draft mode is on; never inline one. Nuxt wiring: [nuxt.md › Real-Time Updates](nuxt.md#real-time-updates-optional).

In Nuxt, use the [server/client query pattern](./nuxt.md#query-composable-with-real-time-subscription): render server-fetched data during SSR and start the subscription only in the browser. The subscription transport accesses `window`. Pass plain values for `token` and `variables`; those options are not unwrapped from Vue refs. Remount a keyed consumer when its query variables change.

Call `useQuerySubscription` synchronously during setup, before any `await`. For pages that can unmount during connection startup, use the explicit `onScopeDispose`/`subscribeToQuery` ownership pattern in the linked reference: register cleanup before awaiting and close a connection that resolves after disposal. The SDK composable in `vue-datocms` 8.1.19 registers cleanup after connecting and can miss that early unmount.

## Contents

- Basic Usage
- Composable Signature
- Initialization Options
- Connection Status
- Error Object
- Integration with Draft Mode
- Full Example with SEO
- Critical: The `fetcher` Gotcha

## Basic Usage

```vue
<script setup>
import { useQuerySubscription } from 'vue-datocms';

const props = defineProps({ token: String });

const { status, error, data } = useQuerySubscription({
  query: `
    query {
      allBlogPosts {
        slug
        title
      }
    }
  `,
  token: props.token,
});

const statusMessage = {
  connecting: 'Connecting to DatoCMS...',
  connected: 'Connected to DatoCMS, receiving live updates!',
  closed: 'Connection closed',
};
</script>

<template>
  <div>
    <p>Connection status: {{ statusMessage[status] }}</p>

    <div v-if="error">
      <h1>Error: {{ error.code }}</h1>
      <div>{{ error.message }}</div>
      <pre v-if="error.response">{{ JSON.stringify(error.response, null, 2) }}</pre>
    </div>

    <ul v-if="data">
      <li v-for="blogPost in data.allBlogPosts" :key="blogPost.slug">
        {{ blogPost.title }}
      </li>
    </ul>
  </div>
</template>
```

## Composable Signature

```ts
const {
  data: Ref<QueryResult | undefined>,
  error: Ref<ChannelErrorData | null>,
  status: Ref<ConnectionStatus>,
} = useQuerySubscription(options);
```

**Important:** Unlike the React hook, the returned `data`, `error`, and `status` are Vue `Ref` values. Access their values with `.value` in `<script>` and use them directly in `<template>`.

## Initialization Options

See `realtime-concepts.md` for the full options table shared across all frameworks.

## Connection Status

See `realtime-concepts.md` for connection status values.

## Error Object

See `realtime-concepts.md` for the error object shape.

## Integration with Draft Mode

When used in a draft mode context, pass the relevant options:

```vue
<script setup>
import { useQuerySubscription } from 'vue-datocms';

const { data } = useQuerySubscription({
  query: QUERY,
  token: draftModeToken,
  includeDrafts: true,
  excludeInvalid: true,
  // For Content Link (visual editing):
  contentLink: 'v1',
  baseEditingUrl: 'https://your-project.admin.datocms.com',
  // Server-fetched data as initial render:
  initialData: serverData,
});
</script>
```

## Full Example with SEO

```vue
<script setup>
import { Image, StructuredText, toHead, useQuerySubscription } from 'vue-datocms';
import { useHead } from '@unhead/vue';
import { computed } from 'vue';

const props = defineProps({ token: String });

const query = `
  query AppQuery($first: IntType) {
    page: blog {
      seo: _seoMetaTags {
        attributes
        content
        tag
      }
    }
    site: _site {
      favicon: faviconMetaTags {
        attributes
        content
        tag
      }
    }
    blogPosts: allBlogPosts(first: $first) {
      id
      title
      slug
      excerpt { value }
      coverImage {
        responsiveImage(imgixParams: { w: 550, auto: format }) {
          src
          width
          height
          alt
          base64
        }
      }
    }
  }
`;

const { data, error, status } = useQuerySubscription({
  query,
  variables: { first: 4 },
  token: props.token,
});

const metaTags = computed(() =>
  toHead(
    data.value ? [...data.value.page.seo, ...data.value.site.favicon] : [],
  ),
);

useHead(metaTags);

const statusMessage = {
  connecting: 'Connecting to DatoCMS...',
  connected: 'Connected to DatoCMS, receiving live updates!',
  closed: 'Connection closed',
};
</script>

<template>
  <div>
    <div>
      <span v-if="status === 'connected'" class="connected-badge" />
      {{ statusMessage[status] }}
    </div>

    <div v-if="error">
      <h1>Error: {{ error.code }}</h1>
      <div>{{ error.message }}</div>
      <pre v-if="error.response">{{ JSON.stringify(error.response, null, 2) }}</pre>
    </div>

    <div v-if="data">
      <article v-for="blogPost in data.blogPosts" :key="blogPost.id">
        <Image :data="blogPost.coverImage.responsiveImage" />
        <h2>{{ blogPost.title }}</h2>
        <StructuredText :data="blogPost.excerpt" />
      </article>
    </div>
  </div>
</template>
```

## Critical: The `fetcher` Gotcha

See `realtime-concepts.md` for the general rule. In Vue, define `fetcher` as a `const` before calling `useQuerySubscription` in `<script setup>`.
