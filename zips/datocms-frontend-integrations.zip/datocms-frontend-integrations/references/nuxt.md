# Nuxt — Preview and Integration Reference

Core below provides authentication and query helpers. For full visual editing, also read the [Content Link controller](./vue-content-link.md#nuxt), [Web Previews](#web-previews-optional), and [real-time query composable](#query-composable-with-real-time-subscription). The controller must be mounted explicitly, and subscriptions run only in the browser; the Core query helper alone does not provide either behavior.

In custom composables, call Nuxt context helpers (`useRuntimeConfig`, `useCookie`, `useRequestEvent`, `useFetch`) and register lifecycle cleanup before the first `await`. An awaited dynamic import can lose that context; capture request values synchronously instead of looking them up afterward.

## Contents

- Core
- Web Previews (Optional)
- Content Link (Optional)
- Real-Time Updates (Optional)
- Cache Tags (Optional)

## Core

### File Structure

```
server/api/
├── draft-mode/
│   ├── enable.ts
│   └── disable.ts
lib/
├── api/
│   ├── draftMode.ts
│   └── utils.ts
composables/
├── useDraftMode.ts          (create)
└── useQuery.ts              (modify existing or create)
nuxt.config.ts               (modify)
```

### Enable Endpoint

**File:** `server/api/draft-mode/enable.ts`

```ts
import { enableDraftMode } from '~/lib/api/draftMode';
import { ensureHttpMethods, isRelativeUrl } from '~/lib/api/utils';

/*
 * This API route enables Draft Mode. If the token is correct, it writes the API
 * Token into a signed cookie that allows access to DatoCMS draft content.
 */
export default eventHandler(async (event) => {
  ensureHttpMethods(event, 'GET');

  const config = useRuntimeConfig();

  const query = getQuery<{ url?: string; token?: string }>(event);
  const url = query.url || '/';

  if (!config.secretApiToken || query.token !== config.secretApiToken) {
    throw createError({
      statusCode: 401,
      message: 'Invalid token',
    });
  }

  if (!isRelativeUrl(url)) {
    throw createError({ status: 422, message: 'URL must be relative!' });
  }

  enableDraftMode(event);

  await sendRedirect(event, url);
});
```

Key points:

- Nuxt auto-imports: `eventHandler`, `getQuery`, `useRuntimeConfig`, `sendRedirect`, `createError`
- `url` param (not `redirect`)
- Token from `useRuntimeConfig().secretApiToken`

### Disable Endpoint

**File:** `server/api/draft-mode/disable.ts`

```ts
import { disableDraftMode } from '~/lib/api/draftMode';
import { ensureHttpMethods, isRelativeUrl } from '~/lib/api/utils';

/*
 * This API route disables Draft Mode, by deleting the signed cookie.
 */
export default eventHandler(async (event) => {
  ensureHttpMethods(event, 'GET');

  const query = getQuery<{ url?: string }>(event);
  const url = query.url || '/';

  if (!isRelativeUrl(url)) {
    throw createError({ status: 422, message: 'URL must be relative!' });
  }

  disableDraftMode(event);

  await sendRedirect(event, url);
});
```

### Draft Mode Helper

**File:** `lib/api/draftMode.ts`

```ts
import { deleteCookie, getCookie, setCookie, type EventHandlerRequest, type H3Event } from 'h3';
import jwt, { type JwtPayload } from 'jsonwebtoken';
import type { CookieSerializeOptions } from 'cookie-es';

/**
 * Generates a JSON Web Token containing the DatoCMS draft CDA token.
 */
function jwtToken() {
  const config = useRuntimeConfig();
  return jwt.sign(
    { datocmsDraftContentCdaToken: config.datocmsDraftContentCdaToken },
    config.signedCookieJwtSecret,
  );
}

const DRAFT_MODE_SERIALIZE_OPTIONS: CookieSerializeOptions = {
  partitioned: true,
  secure: true,
  sameSite: 'none',
};

/**
 * Sets the signed cookie required to enter Draft Mode.
 */
export function enableDraftMode(event: H3Event<EventHandlerRequest>) {
  const config = useRuntimeConfig();
  setCookie(event, config.public.draftModeCookieName, jwtToken(), DRAFT_MODE_SERIALIZE_OPTIONS);
}

/**
 * Disables Draft Mode by deleting the cookie.
 */
export function disableDraftMode(event: H3Event<EventHandlerRequest>) {
  const config = useRuntimeConfig();
  deleteCookie(event, config.public.draftModeCookieName, DRAFT_MODE_SERIALIZE_OPTIONS);
}

/**
 * Checks if Draft Mode is enabled for a given request by verifying the JWT.
 */
export function isDraftModeEnabled(event: H3Event<EventHandlerRequest>) {
  const config = useRuntimeConfig();
  const cookie = getCookie(event, config.public.draftModeCookieName);

  if (!cookie) {
    return false;
  }

  try {
    const payload = jwt.verify(cookie, config.signedCookieJwtSecret) as JwtPayload;
    return !!payload.datocmsDraftContentCdaToken;
  } catch (e) {
    return false;
  }
}

/**
 * Returns the HTTP headers needed to enable Draft Mode.
 */
export function draftModeHeaders(): HeadersInit {
  const config = useRuntimeConfig();
  return {
    Cookie: `${config.public.draftModeCookieName}=${jwtToken()};`,
  };
}
```

Key points:

- JWT payload contains draft CDA token (`datocmsDraftContentCdaToken`) — decoded client-side for real-time
- Import H3 cookie helpers explicitly because this shared module can also be loaded outside Nitro's server directory.
- Cookie opts: `partitioned: true`, `secure: true`, `sameSite: 'none'`

### Utils

**File:** `lib/api/utils.ts`

```ts
import type { EventHandlerRequest, H3Event, HTTPMethod } from 'h3';
import { serializeError } from 'serialize-error';

/**
 * Ensure that an incoming request method matches one of the allowed methods.
 */
export function ensureHttpMethods(event: H3Event<EventHandlerRequest>, ...methods: HTTPMethod[]) {
  const normalizedMethods = Array.isArray(methods) ? methods : [methods];

  if (normalizedMethods.includes(event.method)) {
    return;
  }

  throw createError({
    statusCode: 401,
    message: `Invalid HTTP method, only the following methods are accepted: ${normalizedMethods.join(', ')}`,
  });
}

/**
 * Handle any unexpected errors in an API route.
 */
export function handleUnexpectedError(error: unknown) {
  try {
    throw error;
  } catch (e) {
    console.error(e);
  }

  const { message, ...data } = serializeError(error);

  throw createError({
    statusCode: 500,
    message: message ?? 'An unexpected error occurred',
    data,
  });
}

export function isRelativeUrl(path: string): boolean {
  if (
    path !== path.trim() ||
    /[\u0000-\u001F\u007F\\]/.test(path) ||
    path.startsWith('//') ||
    /^[a-z][a-z0-9+.-]*:/i.test(path)
  ) {
    return false;
  }

  try {
    const base = new URL('https://preview.invalid/');
    return new URL(path, base).origin === base.origin;
  } catch {
    return false;
  }
}
```

Key points:

- `createError` from Nuxt auto-imports (H3)
- Throw errors, don't return Response
- `ensureHttpMethods` validates HTTP methods

### `useDraftMode` Composable

**File:** `composables/useDraftMode.ts`

```ts
import { jwtDecode } from 'jwt-decode';

export function useDraftMode() {
  const config = useRuntimeConfig();
  const cookie = useCookie(config.public.draftModeCookieName);

  if (!cookie.value) {
    return false;
  }

  try {
    return jwtDecode<{ datocmsDraftContentCdaToken: string }>(cookie.value);
  } catch (e) {
    return false;
  }
}
```

Key points:

- Decodes JWT client-side to extract draft CDA token
- Returns `false` if no cookie/invalid JWT
- Returns decoded payload (`datocmsDraftContentCdaToken`) if valid

### Query Composable

**File:** `composables/useQuery.ts`

```ts
import { buildRequestInit } from '@datocms/cda-client';
import type { TadaDocumentNode } from 'gql.tada';
import { hash } from 'ohash';

type Options<Variables> = {
  variables?: Variables;
};

export async function useQuery<Result, Variables>(
  query: TadaDocumentNode<Result, Variables>,
  options?: Options<Variables>,
) {
  const config = useRuntimeConfig();
  const draftMode = useDraftMode();

  const apiToken = draftMode
    ? draftMode.datocmsDraftContentCdaToken
    : config.public.datocmsPublishedContentCdaToken;

  if (!apiToken) {
    throw new Error('Missing API token');
  }

  const data = await useFetch('https://graphql.datocms.com/', {
    ...buildRequestInit(query, {
      token: apiToken,
      includeDrafts: Boolean(draftMode),
      excludeInvalid: true,
      variables: options?.variables,
    }),
    key: hash([query, options]),
    transform: (response: { data: Result; errors?: any[] }) => {
      if (response.errors)
        throw new Error(
          `Something went wrong while executing the query: ${JSON.stringify(response.errors)}`,
        );
      return response.data;
    },
  });

  return data.data;
}
```

Key points:

- `buildRequestInit` from `@datocms/cda-client` with Nuxt's `useFetch`
- Token: draft from JWT cookie, published from public config
- Returns data directly (no real-time in core)

### Nuxt Config Additions

Add to `nuxt.config.ts`:

```ts
export default defineNuxtConfig({
  runtimeConfig: {
    // set by NUXT_DATOCMS_DRAFT_CONTENT_CDA_TOKEN env variable
    datocmsDraftContentCdaToken: '',
    // set by NUXT_SECRET_API_TOKEN env variable
    secretApiToken: '',
    // set by NUXT_SIGNED_COOKIE_JWT_SECRET env variable
    signedCookieJwtSecret: '',

    public: {
      // set by NUXT_PUBLIC_DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN env variable
      datocmsPublishedContentCdaToken: '',
      // set by NUXT_PUBLIC_DRAFT_MODE_COOKIE_NAME env variable
      draftModeCookieName: '',
    },
  },
});
```

Key points:

- Private: `NUXT_` env vars
- Public: `NUXT_PUBLIC_` env vars

### Core Environment Variables

```
NUXT_PUBLIC_DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN=   # Published content CDA token (public)
NUXT_DATOCMS_DRAFT_CONTENT_CDA_TOKEN=               # Draft content CDA token (private)
NUXT_SECRET_API_TOKEN=                               # Shared secret for endpoint auth (private)
NUXT_SIGNED_COOKIE_JWT_SECRET=                       # JWT signing secret (private)
NUXT_PUBLIC_DRAFT_MODE_COOKIE_NAME=                  # Cookie name, e.g. "datocms-draft-mode" (public)
```

### Core Dependencies

Required:

- `jsonwebtoken` — Sign/verify JWT cookies
- `@types/jsonwebtoken` — TypeScript types (dev)
- `serialize-error` — Serialize error objects
- `jwt-decode` — Decode JWT client-side (`useDraftMode`)

Optional (Web Previews):

- `@datocms/cma-client` — `RawApiTypes`, `ApiTypes`

## Web Previews (Optional)

### Preview Links Endpoint

**File:** `server/api/preview-links/index.ts`

```ts
import type { RawApiTypes } from '@datocms/cma-client';
import { deserializeRawItem } from '@datocms/rest-client-utils';
import { ensureHttpMethods, handleUnexpectedError } from '~/lib/api/utils';
import { recordToWebsiteRoute } from '~/lib/datocms/recordInfo';

type WebPreviewsRequestBody = {
  item: RawApiTypes.Item;
  locale: string;
};

type PreviewLink = {
  label: string;
  url: string;
  reloadPreviewOnRecordUpdate?: boolean | { delayInMs: number };
};

type WebPreviewsResponse = {
  previewLinks: PreviewLink[];
};

/**
 * Implements the Previews webhook required for the "Web Previews" plugin:
 *
 * https://www.datocms.com/marketplace/plugins/i/datocms-plugin-web-previews#the-previews-webhook
 */
export default eventHandler(async (event) => {
  try {
    ensureHttpMethods(event, 'OPTIONS', 'POST');

    if (event.method === 'OPTIONS') {
      return {};
    }

    const config = useRuntimeConfig();

    const { token } = getQuery(event);

    if (!config.secretApiToken || token !== config.secretApiToken) {
      throw createError({ message: 'Invalid token', status: 401 });
    }

    const { item, locale } = await readBody<WebPreviewsRequestBody>(event, {
      strict: true,
    });

    const url = await recordToWebsiteRoute(deserializeRawItem(item), locale);

    const response: WebPreviewsResponse = { previewLinks: [] };

    if (url) {
      if (item.meta.status !== 'published') {
        const draftUrl = new URL('/api/draft-mode/enable', getRequestURL(event));
        draftUrl.searchParams.set('url', url);
        draftUrl.searchParams.set('token', token);
        response.previewLinks.push({
          label: 'Draft version',
          url: draftUrl.toString(),
        });
      }

      if (item.meta.status !== 'draft') {
        const publishedUrl = new URL('/api/draft-mode/disable', getRequestURL(event));
        publishedUrl.searchParams.set('url', url);
        response.previewLinks.push({
          label: 'Published version',
          url: publishedUrl.toString(),
        });
      }
    }

    return response;
  } catch (error) {
    handleUnexpectedError(error);
  }
});
```

Key points:

- `readBody` parses request body (Nuxt auto-import)
- `getRequestURL(event)` for base URL
- `url` as redirect param (matches enable/disable)
- Uses `deserializeRawItem` from `@datocms/rest-client-utils` so `recordToWebsiteRoute` can switch on `item.__itemTypeId`
- CORS via `nuxt.config.ts` route rules, not manual headers

### `recordToWebsiteRoute`

**File:** `lib/datocms/recordInfo.ts`

Requires `cma-types` — generated types expose `Schema.X.ID` (literal-typed model id) and the `AnyModel` union, which discriminates `item.attributes` per branch.

```ts
import type { RawApiTypes } from '@datocms/cma-client';
import * as Schema from '~/lib/datocms/cma-types';

/**
 * Maps a DatoCMS record to its frontend URL. Used by the preview-links endpoint.
 */
export async function recordToWebsiteRoute(
  item: RawApiTypes.Item<Schema.AnyModel>,
  _locale: string,
): Promise<string | null> {
  switch (item.__itemTypeId) {
    // Replace with your project's models. Each `case Schema.X.ID` narrows
    // `item.attributes` to that model's fields — no `as` casts needed.
    //
    // case Schema.Page.ID:
    //   return `/${item.attributes.slug}`;
    //
    // case Schema.BlogPost.ID:
    //   return `/blog/${item.attributes.slug}`;

    default:
      return null;
  }
}
```

### Nuxt Config CORS Addition

Add CORS route rule to `nuxt.config.ts`:

```ts
export default defineNuxtConfig({
  // ... existing config ...
  routeRules: {
    // Add CORS headers on API routes
    '/api/**': { cors: true },
  },
});
```

### Web Previews Dependencies

Required: `@datocms/rest-client-utils`

## Content Link (Optional)

### Note on Nuxt Content Link Support

Nuxt starter kit doesn't use `contentLink` or `baseEditingUrl` in query function. `useDraftMode` decodes JWT for real-time but doesn't pass Content Link options.

To add Content Link, modify `useQuery` composable:

```ts
import { buildRequestInit } from '@datocms/cda-client';
import type { TadaDocumentNode } from 'gql.tada';
import { hash } from 'ohash';

type Options<Variables> = {
  variables?: Variables;
};

export async function useQuery<Result, Variables>(
  query: TadaDocumentNode<Result, Variables>,
  options?: Options<Variables>,
) {
  const config = useRuntimeConfig();
  const draftMode = useDraftMode();

  const apiToken = draftMode
    ? draftMode.datocmsDraftContentCdaToken
    : config.public.datocmsPublishedContentCdaToken;

  if (!apiToken) {
    throw new Error('Missing API token');
  }

  const data = await useFetch('https://graphql.datocms.com/', {
    ...buildRequestInit(query, {
      token: apiToken,
      includeDrafts: Boolean(draftMode),
      excludeInvalid: true,
      variables: options?.variables,
      contentLink: draftMode ? 'v1' : undefined,
      baseEditingUrl: config.public.datocmsBaseEditingUrl,
    }),
    key: hash([query, options]),
    transform: (response: { data: Result; errors?: any[] }) => {
      if (response.errors)
        throw new Error(
          `Something went wrong while executing the query: ${JSON.stringify(response.errors)}`,
        );
      return response.data;
    },
  });

  return data.data;
}
```

### Nuxt Config Content Link Addition

Add `baseEditingUrl` to public runtime config in `nuxt.config.ts`:

```ts
export default defineNuxtConfig({
  runtimeConfig: {
    // ... existing config ...
    public: {
      // ... existing public config ...
      // set by NUXT_PUBLIC_DATOCMS_BASE_EDITING_URL env variable
      datocmsBaseEditingUrl: '',
    },
  },
});
```

### ContentLink Component Setup

Use the [Nuxt controller component](./vue-content-link.md#nuxt). It owns its routing callback and updates the path in `router.afterEach` before DOM stamping. Mount the wrapper without passing a second routing callback from its parent.

Add to layout, render only when draft mode enabled. Wrap in `<ClientOnly>`:

```vue
<script setup lang="ts">
const draftMode = useDraftMode();
</script>

<template>
  <ClientOnly>
    <ContentLink v-if="draftMode" />
  </ClientOnly>
  <slot />
</template>
```

### Structured Text with Content Link

Render Structured Text with `vue-datocms`. Wrap in group, add boundaries to embedded blocks/inline records:

```vue
<script setup lang="ts">
import { StructuredText } from 'vue-datocms';
import { stripStega } from '@datocms/content-link';
import { h } from 'vue';

const props = defineProps<{ page: any }>();
</script>

<template>
  <div data-datocms-content-link-group>
    <StructuredText
      :data="page.content"
      :render-block="({ record }) =>
        h('div', { 'data-datocms-content-link-boundary': '' }, [
          h(BlockComponent, { block: record }),
        ])
      "
      :render-inline-record="({ record }) =>
        h('span', { 'data-datocms-content-link-boundary': '' }, [
          h(InlineRecordComponent, { record }),
        ])
      "
      :render-link-to-record="({ record, children, transformedMeta }) =>
        h('a', { ...transformedMeta, href: `/posts/${stripStega(record.slug)}` }, children)
      "
    />
  </div>
</template>
```

Note: `renderLinkToRecord` doesn't need boundary — record links wrap text in the structured text field, so clicking opens that field editor.

### Non-Text Field Example

Fields without stega (numbers, booleans, dates, JSON): use `data-datocms-content-link-url` with `_editingUrl`:

```graphql
query {
  product {
    name
    price
    _editingUrl
  }
}
```

```vue
<template>
  <span :data-datocms-content-link-url="product._editingUrl">
    ${{ product.price }}
  </span>
</template>
```

### CSP Header for Web Previews Visual Tab

Nuxt handles CORS via `routeRules`. If the site already sends a `frame-ancestors` directive, make sure it allows both the exact DatoCMS project origin and the plugin CDN. Browsers check every ancestor in the nested iframe chain. If the directive is absent, do not add it solely for Web Previews.

For example, update the existing CSP route rule in `nuxt.config.ts`, replacing `your-project` with the project's actual subdomain (or use its custom DatoCMS admin origin):

```ts
export default defineNuxtConfig({
  // ... existing config ...
  routeRules: {
    '/api/**': { cors: true },
    '/**': {
      headers: {
        'Content-Security-Policy': "frame-ancestors 'self' https://your-project.admin.datocms.com https://plugins-cdn.datocms.com",
      },
    },
  },
});
```

### Stega Stripping

Content Link embeds invisible chars in text fields. Use `stripStega()` from `@datocms/content-link` before string comparisons, SEO metadata, analytics, URL generation from stega-carrying text. DatoCMS `slug` field type never carries stega — use directly. See `content-link-concepts.md`.

### Content Link Environment Variables

```
NUXT_PUBLIC_DATOCMS_BASE_EDITING_URL=   # For Content Link, e.g. https://your-project.admin.datocms.com
```

### Content Link Dependencies

- `@datocms/content-link` — Click-to-edit overlays, stega utilities

## Real-Time Updates (Optional)

### Query Composable with Real-Time Subscription

Replace Core `useQuery` with real-time subscription version:

**File:** `composables/useQuery.ts`

```ts
import { buildRequestInit } from '@datocms/cda-client';
import type { TadaDocumentNode } from 'gql.tada';
import { hash } from 'ohash';
import { subscribeToQuery } from 'datocms-listen';
import { onScopeDispose, shallowRef } from 'vue';

const isServer = typeof window === 'undefined';

type Options<Variables> = {
  variables?: Variables;
};

export async function useQuery<Result, Variables>(
  query: TadaDocumentNode<Result, Variables>,
  options?: Options<Variables>,
) {
  const config = useRuntimeConfig();
  const draftMode = useDraftMode();

  const apiToken = draftMode
    ? draftMode.datocmsDraftContentCdaToken
    : config.public.datocmsPublishedContentCdaToken;

  if (!apiToken) {
    throw new Error('Missing API token');
  }

  const initialData = useFetch('https://graphql.datocms.com/', {
    ...buildRequestInit(query, {
      token: apiToken,
      includeDrafts: Boolean(draftMode),
      excludeInvalid: true,
      variables: options?.variables,
    }),
    key: hash([query, options]),
    transform: (response: { data: Result; errors?: any[] }) => {
      if (response.errors)
        throw new Error(
          `Something went wrong while executing the query: ${JSON.stringify(response.errors)}`,
        );
      return response.data;
    },
  });

  if (!draftMode || isServer) return (await initialData).data;

  const data = shallowRef<Result>();
  let disposed = false;
  let unsubscribe: (() => void) | undefined;
  onScopeDispose(() => {
    disposed = true;
    unsubscribe?.();
  });

  await initialData;
  if (disposed) return data;
  data.value = initialData.data.value as Result | undefined;
  void subscribeToQuery<Result, Variables>({
    query,
    variables: options?.variables,
    token: apiToken,
    includeDrafts: true,
    excludeInvalid: true,
    onUpdate: ({ response }) => {
      if (!disposed) data.value = response.data;
    },
  }).then((stop) => {
    if (disposed) stop();
    else unsubscribe = stop;
  }).catch(() => {
    if (!disposed) console.error('Unable to start real-time updates');
  });
  return data;
}
```

Key points:

- Draft mode ON + client-side: `subscribeToQuery` from `datocms-listen`
- Draft mode OFF or server-side: return data directly
- Register disposal before awaiting the fetch, and immediately close a connection that finishes opening after disposal. This covers both navigation during the initial fetch and during subscription startup.

**Combining with Content Link** — Keep `environment`, `contentLink` and `baseEditingUrl` consistent in both `buildRequestInit` and `subscribeToQuery`. Use the selected sandbox for both. If the query selects `_editingUrl`, retain `baseEditingUrl` for published reads too. Pass plain token and variable values to the subscription; key the consuming page by its route when query variables change so the previous subscription is disposed.

### Real-Time Dependencies

- `datocms-listen` — `subscribeToQuery` listener

## Cache Tags (Optional)

CDN-first cache tag invalidation. Forwards DatoCMS cache tags to CDN; purges affected pages when content changes.

### When to Use

- Nuxt deployed behind CDN with tag-based purging (Netlify, Cloudflare, Fastly, Bunny)
- Per-record cache invalidation granularity needed

For webhook payload/CDN header table: `skills/datocms-cda/references/draft-caching-environments.md` → "Cache Tags".

### Server query wrapper

Keep requests in a server utility, preserving the existing draft cookie helper and token selection. Return the cache header alongside the result; do not put draft tokens in public configuration.

The example assumes preview mode exists. For a published-only project, omit the draft helper and draft token, use the published token, and set `includeDrafts: false`. Preserve authenticated preview handling when already configured; do not add preview mode just to enable caching.

**File:** `server/utils/fetchWithCacheTags.ts`

```ts
import { rawExecuteQuery } from '@datocms/cda-client';
import type { TadaDocumentNode } from 'gql.tada';
import type { H3Event } from 'h3';
import { isDraftModeEnabled } from '~/lib/api/draftMode';

export async function fetchWithCacheTags<Result, Variables>(
  event: H3Event,
  query: TadaDocumentNode<Result, Variables>,
  variables?: Variables,
) {
  const config = useRuntimeConfig(event);
  const includeDrafts = isDraftModeEnabled(event);
  const [data, response] = await rawExecuteQuery(query, {
    variables, includeDrafts, excludeInvalid: true,
    token: includeDrafts ? config.datocmsDraftContentCdaToken : config.public.datocmsPublishedContentCdaToken,
    returnCacheTags: !includeDrafts,
    requestInitOptions: includeDrafts ? { cache: 'no-store' } : undefined,
  });
  return { data, cacheTags: response.headers.get('x-cache-tags'), includeDrafts };
}
```

### Setting CDN Headers

Use `createPageCacheTags` from the [manual CDN adapter reference](cache-tag-adapters.md). Collect every query contributing to the response before setting headers once:

```ts
import { createPageCacheTags } from '~/lib/datocms/cache-tags';

export default eventHandler(async (event) => {
  const collector = createPageCacheTags();
  const results = await Promise.all([
    fetchWithCacheTags(event, pageQuery),
    fetchWithCacheTags(event, navigationQuery),
  ]);
  for (const result of results) collector.add(result.cacheTags, result.includeDrafts);
  for (const [name, value] of Object.entries(collector.headers('cloudflare'))) {
    setResponseHeader(event, name, value);
  }
  return results.map(({ data }) => data);
});
```

Use the selected CDN, not the example provider automatically. For SSR pages, share the collector through the request and finalize after all page/layout queries finish. Configure any Nitro/CDN cache lookup to bypass draft requests; response headers cannot undo an earlier cache hit.

### Webhook Handler

Implement the [purge adapter contract](cache-tag-adapters.md#purge-adapter-contract), including its failure handling and completion requirements.

**File:** `server/api/invalidate-cache.ts`

Receives DatoCMS cache tag invalidation webhook, calls CDN purge API:

```ts
import { purgeInBatches } from '~/lib/datocms/cache-tags';
import { purgeBatch, purgeBatchSize } from '~/lib/datocms/purge-adapter';
import { ensureHttpMethods } from '~/lib/api/utils';

export default eventHandler(async (event) => {
  ensureHttpMethods(event, 'POST');

  const config = useRuntimeConfig();

  const authHeader = getHeader(event, 'authorization');
  if (!config.cacheInvalidationWebhookSecret || authHeader !== `Bearer ${config.cacheInvalidationWebhookSecret}`) {
    throw createError({ statusCode: 401, message: 'Unauthorized' });
  }

  const body = await readBody(event);
  const tags: string[] = body?.entity?.attributes?.tags;
  if (!Array.isArray(tags) || tags.some((tag) => typeof tag !== 'string' || !tag)) {
    throw createError({ statusCode: 400, message: 'Invalid tags' });
  }

  if (tags.length === 0) {
    return { purged: false };
  }

  try {
    await purgeInBatches(tags, purgeBatchSize, purgeBatch);
  } catch {
    throw createError({ statusCode: 502, message: 'Cache invalidation failed' });
  }

  return { purged: true, tags };
});
```

### Nuxt Config Cache Tags Addition

Add webhook secret + CDN vars to `nuxt.config.ts`:

```ts
export default defineNuxtConfig({
  runtimeConfig: {
    // ... existing config ...
    // set by NUXT_CACHE_INVALIDATION_WEBHOOK_SECRET env variable
    cacheInvalidationWebhookSecret: '',
    // CDN-specific (example for Fastly):
    // set by NUXT_FASTLY_SERVICE_ID env variable
    // fastlyServiceId: '',
    // set by NUXT_FASTLY_KEY env variable
    // fastlyKey: '',
  },
});
```

### Cache Tags Environment Variables

```
NUXT_CACHE_INVALIDATION_WEBHOOK_SECRET=   # Shared secret to verify webhook requests
# CDN-specific vars (uncomment for your CDN):
# NUXT_FASTLY_SERVICE_ID=                 # Fastly service ID
# NUXT_FASTLY_KEY=                        # Fastly API key
```

### Cache Tags Dependencies

None — `rawExecuteQuery` from `@datocms/cda-client` (already installed).
