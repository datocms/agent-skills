---
name: datocms-plugin
description: >-
  Build, scaffold, wire, maintain, test, and release DatoCMS plugins with
  datocms-plugin-sdk. Use when users ask to create a new DatoCMS plugin
  project, patch an existing plugin, add or adjust connect() hooks and their
  ctx (field extensions, config screens, sidebars, pages, modals, inspectors,
  outlets, asset sources, dropdown actions, lifecycle hooks), read or write
  form values and plugin parameters, browser CMA flows, plugin permissions,
  package metadata, testing local plugin changes without affecting the live
  installation, or publishing and switching plugin versions. How a plugin's
  UI looks, which datocms-react-ui components to use, dark mode, and
  upgrading datocms-react-ui belong to datocms-plugin-design. Route
  standalone CMA scripts to datocms-cma and frontend website integrations to
  datocms-frontend-integrations.
---

# DatoCMS Plugin

Plugin code: patch in place; scaffold only when requested or absent. A project's plugin installation is CMA data, not plugin code — install, enable/disable, switch marketplace package ↔ private URL or version, edit global `parameters` → `datocms-cma` [plugin operations](../datocms-cma/references/resource-gotchas.md#plugins-plugins). Local testing without touching the working installation: [development copy](references/project-scaffold.md#development-copy).

## Workflow

1. Inspect silently:
   - `package.json`, package manager, scripts, plugin metadata, and installed SDK/UI versions
   - top-level `connect()` call, usually `src/main.tsx` or `src/index.tsx`
   - touched hook pair, render component, helper, CSS file, and current UI pattern
   - plugin-local `AGENTS.md` if present
2. Classify the request:
   - **Existing plugin:** package already exists and user asks to patch, add, maintain, fix, release-prep, or restyle. Default here.
   - **New plugin:** user asks to create/scaffold/bootstrap a plugin folder, or no plugin project exists.
   - **UI work** (layout, components, styling, dark mode, react-ui upgrade): also load `datocms-plugin-design`; this skill keeps the hook wiring.
3. Ask only when inspection cannot resolve a behavior-changing choice:
   - plugin/folder name for a new scaffold
   - private vs marketplace plugin when package metadata changes
   - target model/field/surface when several are plausible
   - whether a new permission or dependency is allowed
   - whether direct browser CMA calls are required instead of SDK helpers
4. Load references after file inspection. Use the reference for the touched surface; do not load the full bundle.
5. Patch in place:
   - keep the existing file layout, package manager, scripts, naming, and UI structure
   - update paired hooks together: declaration + render, trigger + modal, dropdown declaration + execute handler
   - update permissions and package metadata in the same patch when the code path needs them
   - add dependencies only when the implementation imports them
6. Verify with the plugin's existing command. Prefer the build script; add typecheck, lint, or tests only when the project already defines them and they cover the change.
7. Report the patch, command result, and remaining DatoCMS check: config save, field render, modal resolve, asset select, permission branch, page navigation, or resize behavior.

## Reference map

### Common

| Need | Load |
| - | - |
| Follow-up maintenance shortcuts | `references/rapid-patterns.md` |
| Exact `connect()`, hook pairs, render helper, Canvas, frame sizing | `references/sdk-connect-and-frames.md` |
| Base `ctx`, entity repos, form values, browser CMA, endpoints, async errors | `references/sdk-context-and-cma.md` |
| Target code has no clear precedent | `references/current-plugin-patterns.md` |
| Plugin permission changes | `references/permissions.md` |
| Localized values, field paths, Structured Text Slate form values | `references/form-values.md` |

### New plugin

| Need | Load |
| - | - |
| Project files and package baseline | `references/project-scaffold.md` |
| First hook pair selection | `references/surface-starters.md` |

### Surfaces

| Surface | Load |
| - | - |
| Config screen | `references/config-screen.md` |
| Field extension | `references/field-extensions.md` |
| Sidebar panel or full record sidebar | `references/sidebar-panels.md` |
| Custom page | `references/custom-pages.md` |
| Dropdown action | `references/dropdown-actions.md` |
| Lifecycle hook | `references/lifecycle-hooks.md` |
| Modal | `references/modals.md` |
| Outlet | `references/outlets.md` |
| Inspector | `references/inspectors.md` |
| Asset source | `references/asset-sources.md` |
| Upload sidebar or upload panel | `references/upload-sidebars.md` |
| Structured Text customization | `references/structured-text.md` |
| Record presentation or picker query | `references/record-presentation.md` |

### UI

| Need | Load |
| - | - |
| Any surface that renders UI, restyling, dark mode, upgrade from `datocms-react-ui` 2.x | `../datocms-plugin-design/SKILL.md` (setup contract, rules, surface shells, all react-ui.datocms.com pages) |

## Guardrails

- Keep exactly one top-level `connect()` call.
- Inspect existing `connect()` before adding hooks.
- `datocms-react-ui` 4 only: if `npm view datocms-react-ui version` is below 4, install exactly `4.0.0-next.8` (a bare install gets 2.x); one import per entry (`datocms-react-ui/Button`), never the root.
- Import `datocms-react-ui/styles.css` once in the plugin entry file; keep `src/vite-env.d.ts` (`/// <reference types="vite/client" />`) or TS rejects it.
- Wrap every rendered surface in `<Canvas ctx={ctx}>` (no `noAutoResizer` unless the plugin sets its own height).
- Use `switch` for ID-dispatched render hooks.
- Use `import type { ... }` for SDK types.
- Guard `ctx.item` before reading saved-record data.
- Use `get(ctx.formValues, ctx.fieldPath)` in field extensions; use localized-value helpers elsewhere.
- Use deep-compare effects when depending on `ctx` object properties.
- Keep `ctx.openModal()` parameters and `ctx.resolve()` values JSON-serializable.
- Normalize stored plugin parameters at read/save boundaries.
- Use `ctx.setParameters()` directly in `renderManualFieldExtensionConfigScreen`.
- Modular Content is `rich_text` in `FieldType` and API `field_type`. Do not create editor field extensions for Modular Content, single block, or Structured Text fields; use addons (Modular Content: `fieldTypes: ['rich_text']`; single block has no `FieldType`: `overrideFieldExtensions`, or `fieldTypes: 'all'` if every field type may offer it).
- Prefer SDK helpers before browser CMA calls. If browser CMA is required, use `@datocms/cma-client-browser`, add only required permissions, and guard missing `ctx.currentUserAccessToken`.

## Routing

- DAST analysis, validation, or transforms → **datocms-structured-text**: [document model](../datocms-structured-text/references/document-model.md), [editing](../datocms-structured-text/references/editing.md), or [conversion](../datocms-structured-text/references/conversion.md). Keep Slate form values and editor hooks here; never pass DAST to `ctx.setFieldValue`. Load the specialist only for DAST work. Missing sibling reference → install that skill from `datocms/agent-skills` or update the full bundle.

- Website preview, Content Link, draft mode, cache tags, frontend rendering, or framework wiring -> `datocms-frontend-integrations`; guided multi-part website setup -> `datocms-setup`.

- Content modeling decisions -> `datocms-content-modeling`.

- Content delivery GraphQL query work -> `datocms-cda`.
