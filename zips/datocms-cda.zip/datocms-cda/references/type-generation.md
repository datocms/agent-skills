# Type Generation Setup

## Contents

- Which Approach?
- gql.tada
- GraphQL Code Generator
- CMA Schema Types

## Which Approach?

| | gql.tada | GraphQL Code Generator |
| - | - | - |
| **Best for** | New projects, simpler setups | Existing codegen pipelines, `.graphql` file workflows |
| **Query style** | `graphql()` tagged template in `.ts` files | Queries in `.graphql` files or inline with codegen |
| **Fragment style** | Fragment masking via `readFragment()` + `FragmentOf<>` | Fragment masking via `getFragmentData()` + `FragmentType<>` |
| **Type generation** | Automatic via TS plugin (IDE) + schema file | Manual `graphql-codegen` CLI command |
| **Used in** | All DatoCMS starters | DatoCMS fully-fledged demos |

Both approaches produce `TypedDocumentNode` — the `executeQuery` function from `@datocms/cda-client` accepts either and returns fully typed results.

## gql.tada

### Install

```bash
npm install gql.tada
npm install --save-dev dotenv-cli
```

### Generate Schema

Add to `package.json` scripts:

```json
"generate-schema": "dotenv -c -- bash -c 'gql.tada generate schema https://graphql.datocms.com --header \"X-Exclude-Invalid: true\" --header \"Authorization: $DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN\" && gql.tada generate-output'"
```

Two commands chained — `generate schema` fetches `schema.graphql`, `generate-output` writes the `.d.ts` from it. Always run together; the `.d.ts` is stale without a fresh schema. Re-run after model changes. The tsconfig plugin (below) regenerates the `.d.ts` live in the IDE, but CI builds need this script before `tsc`.

> **Token env var:** The command above uses `DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN` (the name in the official starters and the frontend framework references). If your project uses a different name like `DATOCMS_CDA_TOKEN`, adjust the command accordingly.

> **Framework env var conventions:** SvelteKit prefixes with `PRIVATE_` (e.g., `PRIVATE_DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN`). Nuxt prefixes with `NUXT_PUBLIC_` (e.g., `NUXT_PUBLIC_DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN`).

### tsconfig.json Plugin

Add to `compilerOptions.plugins`:

```json
{
  "name": "gql.tada/ts-plugin",
  "schema": "./schema.graphql",
  "tadaOutputLocation": "./src/lib/datocms/graphql-env.d.ts"
}
```

**Framework differences:**

| Framework | Plugin name | Output path |
| - | - | - |
| Next.js | `gql.tada/ts-plugin` | `./src/lib/datocms/graphql-env.d.ts` |
| Astro | `gql.tada/ts-plugin` | `./src/lib/datocms/graphql-env.d.ts` |
| SvelteKit | `@0no-co/graphqlsp` | `./src/lib/datocms/graphql-env.d.ts` |
| Nuxt | `gql.tada/ts-plugin` | `./<srcDir>/lib/datocms/graphql-env.d.ts` (e.g. `./app/lib/...` on Nuxt 4 with `app/`) |

SvelteKit uses `@0no-co/graphqlsp` (the underlying LSP plugin) instead of `gql.tada/ts-plugin`. It's a `gql.tada` dependency the official SvelteKit starter gets through npm hoisting; not in root `node_modules` (pnpm) → add `@0no-co/graphqlsp` as a dev dependency. Nuxt: `<srcDir>` = `app/` when that folder exists (Nuxt 4), else root, never `src/` by default ([nuxt.md › File Structure](../../datocms-frontend-integrations/references/nuxt.md#file-structure)).

### Initialization File

Create the `graphql.ts` file at the output path's directory (e.g., `src/lib/datocms/graphql.ts`):

```ts
import { initGraphQLTada } from 'gql.tada';
import type { introspection } from './graphql-env.js';

export const graphql = initGraphQLTada<{
  introspection: introspection;
  scalars: {
    BooleanType: boolean;
    CustomData: Record<string, string>;
    Date: string;
    DateTime: string;
    FloatType: number;
    IntType: number;
    ItemId: string;
    JsonField: unknown;
    MetaTagAttributes: Record<string, string>;
    UploadId: string;
  };
}>();

export { readFragment } from 'gql.tada';

export type { FragmentOf, ResultOf, VariablesOf } from 'gql.tada';
```

The `scalars` object maps DatoCMS custom GraphQL scalars to TypeScript types. See `client-and-config.md` for the full scalar reference.

### Key Exports

| Export | Purpose |
| - | - |
| `graphql` | Tagged template function — wraps queries and fragments for type inference |
| `readFragment` | Unmasks a fragment result to access its typed data |
| `FragmentOf<typeof fragment>` | Type of a masked fragment reference (used in component props) |
| `ResultOf<typeof query>` | Inferred result type of a query or fragment |
| `VariablesOf<typeof query>` | Inferred variables type of a query |

## GraphQL Code Generator

### Install

```bash
npm install @graphql-typed-document-node/core graphql
npm install --save-dev @graphql-codegen/cli @graphql-codegen/client-preset graphql-config dotenv
```

`dotenv` backs the config's `import 'dotenv/config'`. Repo also runs dotenv-cli scripts (`dotenv -c --`) → install `dotenv@17`: dotenv 18+ ships its own `dotenv` bin that can shadow dotenv-cli's and fail those scripts.

> The `client` preset bundles `@graphql-codegen/typescript`, `@graphql-codegen/typescript-operations`, and `@graphql-codegen/typed-document-node` — no need to install them separately.

### Configuration

Create `graphql.config.ts` at the project root:

```ts
import 'dotenv/config';
import type { IGraphQLConfig } from 'graphql-config';

const config: IGraphQLConfig = {
  schema: [
    {
      'https://graphql.datocms.com': {
        headers: {
          Authorization: `Bearer ${process.env.DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN}`,
          'X-Exclude-Invalid': 'true',
        },
      },
    },
  ],
  documents: ['./app/**/*.graphql', './components/**/*.graphql'],
  extensions: {
    codegen: {
      generates: {
        'graphql/types/': {
          preset: 'client',
          presetConfig: {
            fragmentMasking: { unmaskFunctionName: 'getFragmentData' },
          },
          config: {
            strictScalars: true,
            scalars: {
              BooleanType: 'boolean',
              CustomData: 'Record<string, string>',
              Date: 'string',
              DateTime: 'string',
              FloatType: 'number',
              IntType: 'number',
              ItemId: 'string',
              JsonField: 'unknown',
              MetaTagAttributes: 'Record<string, string>',
              UploadId: 'string',
            },
          },
        },
      },
    },
  },
};

export default config;
```

Adjust the `documents` glob to match where your `.graphql` files live. Glob matching no files → run fails (`Unable to find any GraphQL type definitions…`): add `.graphql` documents first, or set `ignoreNoDocuments: true` in `extensions.codegen`. `dotenv/config` reads only `.env`; token in `.env.local` → `import { config as loadEnv } from 'dotenv'; loadEnv({ path: ['.env.local', '.env'] });` (first file wins).

### Generate Script

Add to `package.json` scripts:

```json
"generate-ts-types": "graphql-codegen --config graphql.config.ts"
```

### Generated Output

| File | Contents |
| - | - |
| `graphql/types/graphql.ts` | All TypeScript types for your schema |
| `graphql/types/gql.ts` | `graphql()` function for typed document nodes |
| `graphql/types/fragment-masking.ts` | `getFragmentData()` and `FragmentType` helpers |
| `graphql/types/index.ts` | Re-exports from all generated files |

### Key Imports

| Import | Source | Purpose |
| - | - | - |
| `graphql` | `graphql/types/gql` | Wraps `.graphql` content into `TypedDocumentNode` |
| `getFragmentData` | `graphql/types/fragment-masking` | Unmasks a fragment result to access typed data |
| `FragmentType<typeof fragment>` | `graphql/types/fragment-masking` | Type of a masked fragment reference (used in component props) |

### `.graphql` File Pattern

With graphql-codegen, queries and fragments are typically colocated in `.graphql` files next to their components:

```
components/
  BlogPost/
    BlogPost.tsx
    BlogPost.graphql    ← fragment definition
app/
  blog/
    page.graphql        ← page query
    page.tsx
```

The `documents` glob in `graphql.config.ts` controls which files are scanned.

## CMA Schema Types

For generating TypeScript types for CMA record operations (`datocms schema:generate`), see the CMA skill's `references/type-generation.md`. If the CMA skill is not installed, ask the user to install it.
