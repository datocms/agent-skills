# Images and Videos

## Contents

- `responsiveImage` Query
- Common imgix Parameters
- Placeholder Images
- Focal Point
- Upload / File Field Properties
- Video (Mux Integration)
- Complete Example

## `responsiveImage` Query

The `responsiveImage` sub-selection on file/asset fields returns a pre-computed responsive image object ready for `<img>` or `<picture>` elements. It accepts `imgixParams` for image transformations and an optional `sizes` attribute.

```graphql
query {
  blogPost(filter: { slug: { eq: "hello-world" } }) {
    coverImage {
      responsiveImage(
        imgixParams: { fm: jpg, fit: crop, w: 800, h: 400 }
        sizes: "(max-width: 800px) 100vw, 800px"
      ) {
        src
        srcSet
        webpSrcSet
        sizes
        width
        height
        aspectRatio
        alt
        title
        base64
        bgColor
      }
    }
  }
}
```

### `responsiveImage` Fields

| Field | Type | Description |
| - | - | - |
| `src` | `String!` | The fallback image URL |
| `srcSet` | `String!` | HTML5 `srcSet` attribute for multiple resolutions |
| `webpSrcSet` | `String!` | `srcSet` in WebP format for supporting browsers |
| `sizes` | `String!` | HTML5 `sizes` attribute (media query conditions) |
| `width` | `IntType!` | Image width in pixels |
| `height` | `IntType!` | Image height in pixels |
| `aspectRatio` | `FloatType!` | Width / height ratio |
| `alt` | `String` | Alternative text for accessibility |
| `title` | `String` | Title attribute |
| `base64` | `String` | Base64-encoded Low Quality Image Placeholder (LQIP) |
| `bgColor` | `String` | Background color placeholder (hex string, alternative to base64) |

## Common imgix Parameters

DatoCMS supports **all** imgix URL API parameters. Common ones:

| Parameter | Type | Description |
| - | - | - |
| `w` | `FloatType` | Width |
| `h` | `FloatType` | Height |
| `fit` | `ImgixParamsFit` | Resize mode: `crop`, `clip`, `fill`, `max`, `min`, `scale` |
| `auto` | `ImgixParamsAuto` | Automatic optimizations. Pass a single value (`auto: format`) or an array (`auto: [format, compress]`) |
| `fm` | `ImgixParamsFm` | Output format: `jpg`, `png`, `webp`, `gif`, `avif` |
| `q` | `IntType` | Quality (1-100) |
| `crop` | `ImgixParamsCrop` | Crop mode: `focalpoint`, `faces`, `entropy`, `edges`, `top`, `bottom`, `left`, `right` (no `center`: omitted = center, unless Focal Point applies) |
| `ar` | `String` | Aspect ratio (e.g., `"16:9"`) |
| `dpr` | `FloatType` | Device pixel ratio |
| `blur` | `IntType` | Gaussian blur (0-2000) |
| `sat` | `IntType` | Saturation (-100 to 100) |

```graphql
responsiveImage(
  imgixParams: { w: 600, h: 400, fit: crop, auto: format, q: 80 }
) {
  src
  srcSet
  width
  height
}
```

**Warning:** Using `trim`, `padding`, or `rotation` imgix parameters causes the API to return incorrect `width` and `height` values. You must manually calculate and override these in your frontend.

**Advanced imgix transformations** (text overlays, face detection cropping, color space, auto-enhance, red-eye removal, etc.) are all supported. See the full imgix URL API reference at <https://docs.imgix.com/apis/url> for the complete list of parameters.

## Placeholder Images

Several placeholder strategies are available directly on file/upload fields (not inside `responsiveImage`):

| Field | Type | Description |
| - | - | - |
| `blurUpThumb` | `String` | Data URL of a tiny blurred thumbnail. Args: `size` (default 24, px), `punch` (1), `quality` (70), `imgixParams` |
| `blurhash` | `String` | BlurHash encoding (compact placeholder) |
| `thumbhash` | `String` | ThumbHash encoding (higher quality than blurhash) |
| `colors` | `[ColorField!]!` | Dominant colors. Each has a `hex` field. |

```graphql
query {
  blogPost(filter: { slug: { eq: "hello-world" } }) {
    coverImage {
      blurUpThumb
      blurhash
      thumbhash
      colors { hex }
      responsiveImage(imgixParams: { w: 800 }) {
        src
        srcSet
        width
        height
        alt
        base64
      }
    }
  }
}
```

**`base64`** (inside `responsiveImage`) and **`blurUpThumb`** (on the file field) both provide LQIP thumbnails. `base64` is computed based on the imgix transformation parameters, while `blurUpThumb` is a tiny thumbnail of the original (its own `size`, `punch`, `quality` and `imgixParams` arguments) image.

## Focal Point

Editor-set focal point auto-applies to `responsiveImage` and `url` when `imgixParams` has `fit: crop` plus `w` + `h` or `ar` — DatoCMS injects `crop=focalpoint&fp-x=…&fp-y=…`. Skipped when `crop` is anything but `focalpoint` (`faces`, `entropy`, `top`…), `fpX`/`fpY` are passed (sent as-is; imgix applies them only with `crop: focalpoint`), or point is default center (0.5, 0.5). Force center crop: `fpX: 0.5, fpY: 0.5`. Debug: `fpDebug: true`. Select `focalPoint { x y }` (0-1 floats) only when frontend needs coordinates.

## Upload / File Field Properties

All upload/file GraphQL types implement the `FileFieldInterface` interface (analogous to `RecordInterface` for records), enabling polymorphic queries across different file field types.

All fields available on a file/upload field:

| Field | Type | Description |
| - | - | - |
| `id` | `UploadId!` | Internal DatoCMS upload ID |
| `url` | `String!` | The asset URL (on imgix CDN for images) |
| `format` | `String!` | File extension (e.g., `"jpg"`, `"png"`, `"pdf"`) |
| `filename` | `String!` | Full original filename |
| `basename` | `String!` | Filename without extension |
| `mimeType` | `String!` | MIME type |
| `size` | `IntType!` | File size in bytes |
| `width` | `IntType` | Image width in pixels (null for non-images) |
| `height` | `IntType` | Image height in pixels (null for non-images) |
| `alt` | `String` | Alternative text |
| `title` | `String` | Title |
| `tags` | `[String!]!` | User-assigned tags |
| `smartTags` | `[String!]!` | AI-generated tags |
| `customData` | `CustomData!` | Custom key-value metadata |
| `author` | `String` | Author attribution |
| `copyright` | `String` | Copyright information |
| `notes` | `String` | Internal notes |
| `colors` | `[ColorField!]!` | Dominant colors (each with `hex`) |
| `blurhash` | `String` | BlurHash placeholder encoding |
| `thumbhash` | `String` | ThumbHash placeholder encoding |
| `blurUpThumb` | `String` | Data URL blurred thumbnail |
| `exifInfo` | `CustomData!` | EXIF metadata for images (camera, exposure, etc.) |
| `focalPoint` | `FocalPoint` | Contains `x` and `y` (0-1 floats) |
| `responsiveImage(...)` | `ResponsiveImage` | Responsive image sub-selection (images only) |
| `video` | `UploadVideoField` | Video metadata (Mux videos only) |

The `url` field also accepts imgix parameters directly:

```graphql
url(imgixParams: { w: 200, h: 200, fit: crop })
```

**Project optimization defaults:** Explicit image parameters override matching project defaults; unspecified defaults still apply. To bypass all project defaults for one image URL, use `skip-default-optimizations=true` in its query string, or the GraphQL equivalent:

```graphql
url(imgixParams: { w: 200, skipDefaultOptimizations: true })
```

Here `w: 200` still applies, but project defaults do not. Keep the defaults unless the task needs a per-image bypass; disabling optimization can produce larger image files, slow page loading, and increase bandwidth usage and traffic costs. This does not require changing project settings.

## Video (Mux Integration)

Video fields use Mux for processing and delivery. The `video` sub-field provides streaming and download URLs:

```graphql
query {
  blogPost(filter: { slug: { eq: "hello-world" } }) {
    videoField {
      video {
        muxPlaybackId
        streamingUrl
        mp4Url(res: high)
        thumbnailUrl(format: jpg)
        width
        height
        duration
        framerate
        thumbhash
      }
    }
  }
}
```

### Video Fields

| Field | Type | Description |
| - | - | - |
| `muxPlaybackId` | `String!` | Mux playback ID (use with Mux Player or HLS.js) |
| `streamingUrl` | `String!` | HLS streaming URL (`https://stream.mux.com/{id}.m3u8`) |
| `mp4Url(res: VideoMp4Res, exactRes: VideoMp4Res)` | `String` | Direct MP4 URL. `res`: `high`, `medium`, or `low` |
| `thumbnailUrl(format: MuxThumbnailFormatType, time, width, height, fitMode, rotate, flipV, flipH)` | `String!` | Video thumbnail. `format`: `jpg`, `png`, or `gif` |
| `width` | `IntType!` | Video width in pixels |
| `height` | `IntType!` | Video height in pixels |
| `duration` | `Int` | Duration in seconds |
| `framerate` | `Int` | Frames per second |
| `thumbhash` | `String` | Base64 preview encoding for placeholder |

**HLS streaming is recommended over MP4** for better adaptive bitrate and performance. Use `muxPlaybackId` with a Mux-compatible player or `streamingUrl` with HLS.js.

**Limit streaming resolution:** Append `?max_resolution=1080p` to the HLS URL (e.g., `https://stream.mux.com/{ID}.m3u8?max_resolution=1080p`) to cap the maximum resolution. Accepted values: `270p`, `360p`, `480p`, `540p`, `720p`, `1080p`, `1440p`, `2160p`.

**Raw video URLs return 422:** DatoCMS blocks direct access to raw video files by default ("Block Serving Raw Videos" setting). Always use HLS streaming or MP4 download URLs from the `video` field instead.

### Framework Video Players

| Framework | Package | Component |
| - | - | - |
| React | `react-datocms/video-player` | `<VideoPlayer>` |
| Vue | `vue-datocms` | `<VideoPlayer>` |
| Svelte | `@datocms/svelte` | `<VideoPlayer>` |

These components accept `data` (the video field result) and handle HLS playback automatically.

## Complete Example

```ts
import { executeQuery } from "@datocms/cda-client";

const query = `
  query HeroImage($slug: String!) {
    blogPost(filter: { slug: { eq: $slug } }) {
      title
      coverImage {
        responsiveImage(
          imgixParams: { w: 1200, h: 630, fit: crop, auto: format }
          sizes: "(max-width: 1200px) 100vw, 1200px"
        ) {
          src
          srcSet
          webpSrcSet
          sizes
          width
          height
          aspectRatio
          alt
          title
          base64
        }
        focalPoint { x y }
        blurhash
        colors { hex }
      }
    }
  }
`;

// Result: this query's shape, hand-written or generated (type-generation.md); a string query is `unknown` without it.
const data = await executeQuery<Result>(query, {
  token: process.env.DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN!,
  variables: { slug: "hello-world" },
});

const image = data.blogPost?.coverImage?.responsiveImage;
if (!image) throw new Error("Blog post or cover image not found");

// Use in an <img> element:
// <img
//   src={image.src}
//   srcSet={image.srcSet}
//   sizes={image.sizes}
//   width={image.width}
//   height={image.height}
//   alt={image.alt}
//   style={{ backgroundImage: `url(${image.base64})`, backgroundSize: 'cover' }}
// />
```
