# Resource gotchas

Use the selected execution mode's endpoint documentation for CRUD signatures. This file covers gotchas, runtime semantics and cross-cutting patterns.

In CLI mode, use `npx datocms cma:docs <resource> <action>`; command options live in `../../datocms-cli/references/direct-cma-calls.md` § cma:docs.

## Contents

- Webhooks (`webhooks`)
- Build triggers (`buildTriggers`)
- Scheduling (`scheduledPublication`, `scheduledUnpublishing`)
- Workflows (`workflows`)
- Saved filters (`itemTypeFilters`, `uploadFilters`)
- Plugins (`plugins`)
- Dashboard and schema menus (`menuItems`, `schemaMenuItems`)
- Upload tracks and tags (`uploadTracks`, `uploadTags`, `uploadSmartTags`)
- Audit log events (`auditLogEvents`)

## Webhooks (`webhooks`)

CLI lookup: `cma:docs webhooks` covers create/update/instances/self/destroy, `events`/`filters`/`custom_payload` shape.

Operational notes:

- **Project-level:** belongs to project, not environment — not forked, untouched by promote. Keep out of migrations (sandbox run changes it live; re-run fails on unique `name`) — create/update through selected CMA route per **Declarative sync**, after approval. Managing needs role flag `can_manage_webhooks`.
- **Environment scope:** events fire in every environment, sandboxes included, unless filtered. Primary only → add `{ entity_type: "environment_type", entity_ids: ["primary"] }` to that event's `filters` (`"sandbox"` for sandboxes; `entity_type: "environment"` + env names for specific ones). Filters in one event entry must all match; `build_trigger`, `maintenance_mode`, `sso_user` events take no environment filter. Payload carries `environment` and `is_environment_primary`.
- **Receiver auth:** send what receiver expects — static `headers` (e.g. `Authorization: Bearer …`) or `http_basic_user` / `http_basic_password` (sent as `Authorization: Basic`, replacing any custom `Authorization` header). Secrets from env vars, never chat.
- **Timeouts:** 2s connection, 8s execution per delivery. Heavy work must be deferred — return 200 fast, process async.
- **Auto-retry** (`auto_retry: true`): up to 7 retries — 2 min, 6 min, 30 min, 1 hr, 5 hrs, 1 day, 2 days.
- **Undeliverable target:** `url` on localhost (DatoCMS can't reach it) or an empty bearer secret (unset env var → `Authorization: Bearer ` → receiver rejects) fails every delivery, each retried per **Auto-retry** — public URL and real secret before enabling.
- **Event lifecycle on draft/published:** create → `create`, publish → `publish`, edit-published → `update`, re-publish → `publish`, unpublish → `unpublish`, delete-published → `unpublish` + `delete`. On models without draft/published: create → `create` + `publish`, update → `update` + `publish`, delete → `unpublish` + `delete`.
- **Cache-tag invalidation** (`entity_type: "cda_cache_tags"`, `event_types: ["invalidate"]`): only `environment` / `environment_type` filters (see **Environment scope**) — otherwise fires for every cache tag change; cannot narrow to specific models/records. Payload carries `entity.attributes.tags: string[]`. For architectural patterns, see `../../datocms-cda/references/draft-caching-environments.md`.
- **Webhook history:** `client.webhookCalls.listPagedIterator({ filter: { fields: { webhook_id: { eq: webhookId } } } })` lists past deliveries; `client.webhookCalls.resendWebhook(callId)` re-delivers failed call.
- **Declarative sync** (repo config → project): `name` is unique — match on it to create or update, never delete unlisted webhooks; updates overwrite dashboard edits to sent fields. Create also requires `custom_payload`, `headers`, `http_basic_user`, `http_basic_password` (`null` / `{}` when unused).

## Build triggers (`buildTriggers`)

CLI lookup: `cma:docs buildTriggers` covers create/update/instances/self/destroy, trigger/abort/reindex actions; deploy history is `buildEvents`. `adapter`: `custom`, `netlify`, `vercel`, `gitlab` only.

Operational notes:

- `autotrigger_on_scheduled_publications: true` bridges scheduling and deploys — without it, scheduled publish/unpublish does **not** trigger build.
- **Project-level** like webhooks — not forked, untouched by promote, keep out of migrations. Managing needs role flag `can_manage_build_triggers`.
- **Declarative sync:** create requires `frontend_url` (nullable), `autotrigger_on_scheduled_publications` and `adapter_settings`, keys per `adapter`: `custom` → `trigger_url`, `headers`, `payload`; `netlify` → `trigger_url`, `access_token`, `branch`, `site_id`; `vercel` → `project_id`, `token`, `branch`, `team_id`, `deploy_hook_url`; `gitlab` → `trigger_url`, `token`, `ref`, `build_parameters`. `name` is unique — match on it to create or update, never delete unlisted ones; updates overwrite dashboard edits to sent fields.

## Scheduling (`scheduledPublication`, `scheduledUnpublishing`)

CLI lookup: `cma:docs scheduledPublication`, `cma:docs scheduledUnpublishing` cover create/destroy, `selective_publication` shape (`{ content_in_locales, non_localized_content }`).

Operational notes:

- `publication_scheduled_at` / `unpublishing_scheduled_at` must be ISO 8601 **in the future** — past timestamps rejected.
- Single record can carry both scheduled publication and scheduled unpublishing simultaneously — time-limited visibility window (publish on Christmas, unpublish on New Year's).
- Scheduled publication triggers deploy only if relevant build trigger has `autotrigger_on_scheduled_publications: true`.

## Workflows (`workflows`)

CLI lookup: `cma:docs workflows` covers create/update/instances/self/destroy, `stages` array shape.

Operational notes:

- Exactly one stage in `stages` must have `initial: true` — new draft records land there.
- Assign workflow to model via `client.itemTypes.update(modelId, { workflow: { id, type: "workflow" } })` — workflows not linked at creation.
- Move records between stages via `client.items.bulkMoveToStage({ items: [{ id, type: "item" }], stage: "review" })` — bulk endpoint is the only API, even for single record.

## Saved filters (`itemTypeFilters`, `uploadFilters`)

CLI lookup: `cma:docs itemTypeFilters`, `cma:docs uploadFilters` cover create/update/instances/self/destroy, `filter` / `columns` / `order_by` / `shared` attributes.

Operational notes:

- `filter` object mirrors **UI's internal filter state** — exact shape depends on which field/meta filters are active in dashboard. Copy from saved view in UI rather than hand-writing.
- `order_by` uses field-name + direction suffix: `"_updated_at_DESC"`, `"_created_at_ASC"`, `"<field_api_key>_ASC"`.
- `shared: true` makes filter visible to all team members; `false` keeps it private to creator. No per-role visibility.

## Plugins (`plugins`)

CLI lookup: `cma:docs plugins` covers create/update/instances/self/destroy/fields and plugin attributes.

Operational notes:

- Pass exactly one of `package_name` (marketplace) or `url` (custom) to `client.plugins.create()` — never both.
- `parameters` is project-specific global configuration; modern plugins define its shape in their code. `parameter_definitions` describes legacy plugins only. An API token or OAuth app whose role cannot edit the schema reads `parameters` as `null` (collaborators and roles with schema or CMS-internals access get the object). Never write back a `parameters` value you read through such a credential: `null` overwrites the stored configuration, so omit the attribute or check it is non-null first.
- `client.plugins.fields(pluginId)` finds fields using that installation. Duplicating a plugin in the CMS does not copy those editor/addon assignments; reassign the intended test fields explicitly.
- Update `enabled` to disable or re-enable an installation without deleting its configuration. Disabled plugins do not run. `enabled` and `package_name` are not in the client's update type (6.1.3): send them with the raw request shown below.

For modern plugins, these updates affect the selected installation; use a [development copy](../../datocms-plugin/references/project-scaffold.md#development-copy) when the original must remain available:

- **Marketplace to private:** update `url`; this clears the package/version association. So does sending `name`, `description` or `permissions` to a Marketplace installation: send only `parameters`, `enabled` or `package_version` to keep it.
- **Private to Marketplace:** update `package_name`; this preserves `parameters` and replaces package metadata and permissions. Send it separately from other attributes except optional `enabled`.
- **Published version:** update `package_version` on a Marketplace installation to select that version.

**SDK compatibility:** Check that the installed SDK supports and serializes `enabled` and `package_name` on update. Older versions can omit these newer attributes; a TypeScript cast does not add serialization support. Use a supporting SDK version or, when an upgrade is unavailable, the documented JSON:API request through `client.request()` or the CMS actions described above.

For that raw fallback, the update is `PUT /plugins/:id` and JSON:API `data.type` is singular `"plugin"`. For example, switching an installation and disabling it while preserving its parameters:

```ts
const pluginId = "EXISTING_INSTALLATION_ID";
await client.request({
  method: "PUT",
  url: `/plugins/${pluginId}`,
  body: {
    data: {
      type: "plugin",
      id: pluginId,
      attributes: {
        package_name: "datocms-plugin-example",
        enabled: false,
      },
    },
  },
});
const affectedFields = await client.plugins.fields(pluginId);
```

Omitting `parameters` retains the saved global settings. The raw request bypasses the older SDK attribute allowlist; casting a simplified `plugins.update()` payload does not.

## Dashboard and schema menus (`menuItems`, `schemaMenuItems`)

CLI lookup: `cma:docs menuItems`, `cma:docs schemaMenuItems` cover create/update/instances/self/destroy, `label` / `position` / `parent` / `item_type` / `external_url` attributes.

Operational notes:

- Leaf `menu_item` references either `item_type` **or** `external_url`, never both. Parent folder typically has neither — just groups children by `parent`.
- `position` is **per-parent** — siblings under same `parent` (or top-level when `parent` is null) ordered by `position` numbers; positions across different parents independent.
- Reordering done by updating `position` on each affected sibling — API has no public "move up/down" or "reorder" action (`menuItems.reorder` exists but is marked private).

## Upload tracks and tags (`uploadTracks`, `uploadTags`, `uploadSmartTags`)

CLI lookup: `cma:docs uploadTracks`, `cma:docs uploadTags`, `cma:docs uploadSmartTags` cover CRUD surface, attributes.

Operational notes:

- **Track creation is async job.** Freshly created track returns with `status: "preparing"`; poll `client.uploadTracks.list(uploadId)` until `status: "ready"` (or `"errored"` with populated `error` field) before treating track as available.
- `language_code` must be **BCP 47** (`"en"`, `"en-US"`, `"fr"`, `"pt-BR"`, …). `type` is `"subtitles"` or `"audio"`. `closed_captions: true` flags SDH (Deaf / Hard-of-hearing) variants.
- **Tags ≠ smart tags.** `client.uploadTags` is user-managed, project-wide tag dictionary; `client.uploadSmartTags` is AI-generated set tied to each upload (read-only, populated by DatoCMS image analysis pipeline). On `upload`, `tags: string[]` carries manual tags; smart tags surfaced through upload's smart-tags endpoint, not on upload object itself.
- Tracks are video-only — adding track to non-video upload errors at create time.

## Audit log events (`auditLogEvents`)

CLI lookup: `cma:docs auditLogEvents` covers `query` / `rawQuery`, filter parameters.

Operational notes:

- **Cursor pagination.** Audit log is the **only** resource that does not use offset/limit. `query()` returns single page, no `meta`; for full traversal use `rawQuery()`, send previous `result.meta.next_token` as `data.attributes.next_token` (no `page` param) until it returns `null`.
- `rawQuery()` returns raw JSON:API — event data sits under `result.data[].attributes`, not flattened like `query()`.
- **Action name prefix matters.** Single-record operations log under `items.*` (`items.create`, `items.publish`, `items.destroy`, …). Bulk operations log under `item_bulk_operations.*` (`item_bulk_operations.publish`, `item_bulk_operations.destroy`, …), emit **single event** with all affected record ids in `request.payload.data.relationships.items` — filtering by request path misses them.
- `detailed_log: true` on `rawQuery` returns full request/response payloads (heavier, useful for forensic debugging).
