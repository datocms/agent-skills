# Client Setup and Error Handling

Load for code that constructs its own client, or for the error-handling details below.

> **Scope:** Package installation, `buildClient()` and token configuration apply when constructing a client for app/server code or unattended automation. When the selected runtime supplies the authenticated client, use it and skip that setup; the CMA error types still apply.

## Contents

- Existing Project Setup
- Package Selection
- Building the Client
- Common Resources
- Error Handling

## Existing Project Setup

Before constructing a client in local app/server code or unattended automation:

1. Inspect `package.json` for the installed CMA package and runtime. Search existing `buildClient()` calls and client wrappers; reuse the package, client configuration, token source, and environment targeting already used by the project.
2. Check existing credential variable names/configuration, including `.env` or `.env.local` when applicable, without printing secret values. An unattended runtime needs a token with `can_access_cma: true` and the role permissions the task requires. A read-only CDA token (`DATOCMS_PUBLISHED_CONTENT_CDA_TOKEN`, `DATOCMS_DRAFT_CONTENT_CDA_TOKEN`, `NEXT_PUBLIC_DATOCMS_API_TOKEN`) is insufficient; request a separate CMA-capable credential only for that runtime. Full access is not required: scope it to the needed models, actions, and environments.
3. Look for existing generated CMA types and generation scripts before adding files or commands. Reuse the current module and output path. Do not proactively introduce type generation; consult `type-generation.md` only when the requested local code needs missing or updated types.

## Package Selection

| Package | Runtime | When to use |
| - | - | - |
| `@datocms/cma-client` | Universal | Recommended for most cases. Works anywhere with native `fetch`. Only provide `fetchFn` if the runtime lacks it. |
| `@datocms/cma-client-node` | Node.js | Use when you need Node.js upload helpers such as `createFromLocalFile()` or `createFromUrl()`. |
| `@datocms/cma-client-browser` | Browser | Use when you need browser upload helpers such as `createFromFileOrBlob()`. |

All three packages expose the same core CMA resources. The main differences are the environment-specific upload convenience methods.

Import `buildBlockRecord`, `ApiError`, and `TimeoutError` from the same client package as `buildClient`. Use `import type` for type-only imports. A runtime-provided client or helper needs no duplicate construction or import.

Install with:

```bash
npm install @datocms/cma-client-node
```

## Building the Client

```ts
import { buildClient } from "@datocms/cma-client-node";

const client = buildClient({
  apiToken: process.env.DATOCMS_API_TOKEN!,
});
```

### Common `ClientConfigOptions`

| Option | Type | Default | Description |
| - | - | - | - |
| `apiToken` | `string \| null` | — | Required. Use a CMA-capable token with the permissions your task needs. |
| `environment` | `string` | — | Targets a sandbox environment. Omit to use the primary environment. |
| `requestTimeout` | `number` | `30000` | Timeout in milliseconds per request. |
| `autoRetry` | `boolean` | `true` | Retries rate limits and transient server failures automatically. |
| `logLevel` | `LogLevel` | `LogLevel.NONE` | Logging verbosity. |
| `logFn` | `(message: string) => void` | `console.log` | Custom log function. |
| `extraHeaders` | `Record<string, string>` | — | Additional headers for every request. |
| `fetchFn` | `typeof fetch` | — | Custom fetch implementation for runtimes without native fetch. |

**Token guidance:**

- CMA operations require `can_access_cma: true`
- Schema changes require a role with `can_edit_schema: true`
- Public browser tokens or read-only CDA tokens are not sufficient for CMA writes

## Common Resources

| Resource | Property | Common operations |
| - | - | - |
| Records | `client.items` | CRUD, publish, unpublish, bulk operations |
| Uploads | `client.uploads` | CRUD, bulk tag/destroy, references |
| Models | `client.itemTypes` | CRUD, duplicate, referencing |
| Fields | `client.fields` | CRUD, duplicate, referencing |
| Environments | `client.environments` | Fork, promote, rename, destroy |
| Webhooks | `client.webhooks` | CRUD |
| Build triggers | `client.buildTriggers` | CRUD, trigger, abort |
| Roles | `client.roles` | CRUD, duplicate |
| API tokens | `client.accessTokens` | CRUD, regenerate |
| Workflows | `client.workflows` | CRUD |
| Site | `client.site` | Find and update site settings (locales, timezone, global SEO) |
| Menu items | `client.menuItems` | CRUD, organize dashboard navigation |
| Schema menu items | `client.schemaMenuItems` | CRUD, organize schema sidebar |
| Plugins | `client.plugins` | CRUD, list fields using a plugin |
| Maintenance mode | `client.maintenanceMode` | Find, activate, deactivate |
| Record filters | `client.itemTypeFilters` | CRUD for saved record list filters |
| Upload filters | `client.uploadFilters` | CRUD for saved upload filters |
| Upload tracks | `client.uploadTracks` | Create, list, destroy video subtitle tracks |
| Upload tags | `client.uploadTags` | List, create manual asset tags |
| Job results | `client.jobResults` | Find async job status (usually auto-polled) |
| Audit log | `client.auditLogEvents` | Query events with filters |
| Subscription limits | `client.subscriptionLimits` | List plan limits and current usage |
| Search results | `client.searchResults` | CMA-side site search |

The client also exposes resources for record versions, webhook calls, SSO, daily usage, subscription features, white-label settings, and more.

> **CLI mode:** Run `npx datocms cma:docs <resource> <action>` to browse detailed, up-to-date endpoint documentation (request body schemas, required fields, parameters, examples) directly in the terminal.

## Error Handling

### `ApiError`

Thrown when the API returns a non-2xx response other than rate limits that are retried automatically.

```ts
import { ApiError } from "@datocms/cma-client-node";

try {
  await client.items.create({
    item_type: { id: "model_123", type: "item_type" },
    title: "Hello",
  });
} catch (error) {
  if (error instanceof ApiError) {
    console.log(error.response.status);
    console.log(error.errors);

    const uniqueError = error.findError("INVALID_FIELD", {
      field: "title",
      code: "VALIDATION_UNIQUE",
    });
    if (uniqueError) {
      console.log(uniqueError.attributes.details);
    }
  }
  throw error;
}
```

**Useful `ApiError` members:**

| Property | Type | Description |
| - | - | - |
| `request` | `{ url, method, headers, body? }` | The failed request |
| `response` | `{ status, statusText, headers, body? }` | The API response |
| `errors` | `ErrorEntity[]` | Parsed DatoCMS error entities |
| `findError()` | method | Finds errors by code and optional detail filters |

### Error codes

Each error entity carries `attributes.code` (e.g. `INVALID_FIELD`, `INSUFFICIENT_PERMISSIONS`, `MISSING_LOCALES`, `STALE_ITEM_VERSION`) plus an `attributes.details` object that often nests a more specific `details.code` (e.g. `INVALID_FORMAT`, `INVALID_LOCALES`, `VALIDATION_UNIQUENESS`) and the offending `field`. Pass that code as the first argument to `error.findError()` and match nested details with its second filter argument, as in the uniqueness example above. These are part of the HTTP response contract, so prefer branching on them over message strings. Full catalogue with meanings and fixes: <https://www.datocms.com/docs/content-management-api/errors.md>.

### `TimeoutError`

Thrown when a request exceeds `requestTimeout` and retries do not recover.

```ts
import { TimeoutError } from "@datocms/cma-client-node";

try {
  await client.items.list();
} catch (error) {
  if (error instanceof TimeoutError) {
    console.log("Request timed out:", error.request.url);
  }
}
```
