_Internal recipe for `datocms-setup`. Use this file only after the parent skill selects the `migration-autogenerate` recipe and queues any prerequisites from `../../../references/recipe-manifest.json`._

# DatoCMS Migration Autogenerate Setup

## Step 1: Detect Context (silent)

1. **Node project** — Check for `package.json`
2. **CLI migrations baseline** — Check for the `datocms` npm package, `datocms.config.json`, and a `migrations/` directory or existing migration scripts
3. **Migration format convention** — Check whether existing migrations in the active profile's `migrations.directory` (else `migrations/`) are TypeScript or JavaScript
4. **Existing helper** — Check for `scripts/datocms-autogenerate-migration.mjs`
5. **Existing scripts** — Check `package.json` for `datocms:migrations:diff`

### Stop conditions

- If the project does not already have working CLI migration setup, stop and record `migrations` as a prerequisite and continue after it is applied.
- If an existing diff helper follows a materially different flow, patch it in place by default and only ask if a rewrite would replace working behavior.

## Step 2: Ask Questions

Only ask if an existing diff helper materially conflicts with the lean autogenerate flow.

## Step 3: Load References

Read only these references:

- `../../../../datocms-cli/references/cli-setup.md`
- `../../../../datocms-cli/references/creating-migrations.md`
- `../../../../datocms-cli/references/running-migrations.md`

Also inspect this bundled asset only when generating files:

- `scripts/datocms-autogenerate-migration.mjs`

## Step 4: Generate Code

Generate only these project changes:

1. **Create or patch `scripts/datocms-autogenerate-migration.mjs`** from `scripts/datocms-autogenerate-migration.mjs`
2. **Patch `package.json`** with `datocms:migrations:diff`

### Required behavior

The helper script must:

1. Accept a migration name
2. Accept `--from=<env>` and optional `--to=<env>`
3. Map those inputs to `migrations:new --autogenerate=<env>` or `migrations:new --autogenerate=<from>:<to>`
4. Preserve the TS or JS format of existing migrations in the directory the CLI writes to (`--config-file`/`--profile` or `DATOCMS_*` env, profile `migrations.directory`, else `./migrations`); otherwise leave inference to the CLI
5. Allow passthrough `--ts`, `--js`, `--schema`, and `--profile`
6. Never run the generated migration automatically
7. Treat the generated migration as schema-only output, not as a records or uploads importer

### Mandatory rules

- Use Node built-ins only in the helper script
- Keep the helper narrow: it creates diff-based migrations and nothing else
- Do not force `--schema` automatically
- Do not run `migrations:run` after creating the file
- Do not add CI files or release helpers in this setup

## Step 5: Install Dependencies

Do not add any dependencies for this setup beyond the existing CLI baseline. The helper must work with Node built-ins only.

## Step 6: Next Steps

After generating the files, tell the user:

1. Review the generated migration before committing it
2. Use the helper for sandbox-vs-primary or explicit environment-pair diffs when they want a schema-only migration
3. Apply the generated migration separately with the normal migrations workflow

## Verification Checklist

Before presenting the result, verify:

1. `scripts/datocms-autogenerate-migration.mjs` exists
2. `package.json` contains `datocms:migrations:diff`
3. The helper builds `--autogenerate` from `--from` and optional `--to`
4. The helper does not execute generated migrations
5. The helper uses `npx datocms`
